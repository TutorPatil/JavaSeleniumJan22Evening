package com.java.classesandobjects;

public class Dog {
	
	String colour;
	int age ;
	String breed ;
	boolean isVaccinated ;
	static int noOfLegs = 4;
	
	
	/*
	 * The constructor is a method like entity
	 * The name of the constructor is same as the name of the class
	 * It will not have any return type
	 * If there is no constructor then the Java Compiler will add the default constructor
	 * It is invoked by the JVM when the object is getting created
	 * The constructors can be overloaded
	 * If the programmer adds any constructor , then the compiler will not add any constructors
	 * this keyword is used  to assign the values to the current object which is getting created...( this object )
	 * 
	 * 
	 */
	
	public Dog(String colour, int age, String breed, boolean isVaccinated) {
		
		this.colour = colour;
		this.age = age;
		this.breed = breed;
		this.isVaccinated = isVaccinated;
	}


	public Dog()
	{
	
	}
	
	
	public Dog(String colour,int age)
	{
		this.colour = colour;
		this.age = age;
		
	}
	
	public void bark()
	{
		System.out.println("The Dog of the breed "+breed + " of the colour "+ colour +
				"Of the age "+age + " which is vaccinated "+ isVaccinated +" is barking bow bow...");
	}
	

}
