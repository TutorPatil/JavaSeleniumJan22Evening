package com.java.classesandobjects;

public class Address {
	
	int flatNo;
	String streetName;
	String area;
	String city;
	
	public Address()
	{
		
	}
	
	public Address(int flatNo, String streetName, String area, String city, int pincode) {
		
		this.flatNo = flatNo;
		this.streetName = streetName;
		this.area = area;
		this.city = city;
		this.pincode = pincode;
	}


	int pincode;
	static String state = "Karnataka";
	
	public String getAddressDetails()
	{
		
		return "The address details are "+ "flatNo " + flatNo+ "streetName "+streetName + "Area " + area + "city " + city + "pincode "+pincode; 
	}

	
	public static String getStateFromAddress()
	{
		
		return " The state is "+state;
	}
}
