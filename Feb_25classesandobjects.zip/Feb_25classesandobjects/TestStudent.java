package com.java.classesandobjects;

public class TestStudent {

	public static void main(String[] args) {
		
		Address a1  = new Address();
		
		a1.flatNo=420;
		a1.streetName="M.G. Road";
		a1.area ="Kacheguda";
		a1.city="Hyderabad";
		a1.pincode=123456;
		
		
		Address a2 = new Address(110,"2nd main road", "JayaNagar","Bangalore",560010);
		
		Student s = new Student();
		
		s.name = "Ramu";
		s.rollNum = 25;
		s.feesPaid=5000;
		s.feesDue = 5000;
		s.gender="Male";
		
		s.a=a1;	
		
		s.doHomeWork();
		s.payYourFess();
		System.out.println(s.getStudentAddressDetails());
		Student.attendExams();
		
		System.out.println("==================");
		
		Student s2 = new Student("Shamu",40,3,4000,6000, "Male", a2);
		
	}

}
