package com.java.classesandobjects;

public class Student {
	
	String name;
	int rollNum;
	int standard;
	int feesPaid;
	int feesDue;
	String gender;
	Address a;	
	static Address a1;	
	static Address out ;
	
	static String schoolName = "Govt Primary School";
	
	public Student()
	{
		
	}
	
	public Student(String name, int rollNum, int standard, int feesPaid, int feesDue, String gender, Address a) {
		
		this.name = name;
		this.rollNum = rollNum;
		this.standard = standard;
		this.feesPaid = feesPaid;
		this.feesDue = feesDue;
		this.gender = gender;
		this.a = a;
	}

	public void doHomeWork()
	{
		System.out.println("The student by name "+name + " has done the homework");		
	}
	
	public void payYourFess()
	{
		System.out.println("The student by name "+name + " has fees due of amount "+feesDue);		
	}
	
	public String getStudentAddressDetails()
	{
		return "Name " +name + " adress Details " + a.getAddressDetails();
		
	}
	
	
	public static void attendExams()
	{
		System.out.println("The student of the school "+schoolName + " has not attended the exams ");
	}


}
