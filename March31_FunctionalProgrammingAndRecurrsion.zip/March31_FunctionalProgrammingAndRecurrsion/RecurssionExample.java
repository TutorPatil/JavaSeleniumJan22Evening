package com.corejava.collections;

public class RecurssionExample {

	public static void main(String[] args) {
		System.out.println(findFactorialRec(5));
	}
	public static void showNumbers(int num)
	{
		
		if( num > 0)
		{
			showNumbers(num - 1);
		}
		
		System.out.println(num);
		
	}
	
	
	public static int findFactorial(int num)
	{
		int fact = 1;
		
		while( num > 1)
		{
			fact = fact * num;
			num--;
		}
		
		
		
		return fact;
		
	}
	
	
	
	public static int findFactorialRec(int num)
	{
		if( num == 1)
		{
			return 1;
		}
		else
		{
			return ( num * (findFactorialRec(num-1) ));
		}
		
		
		
	}
}
