package com.corejava.collections;

public class TestFunctionalIntra {

	public static void main(String[] args) {
		/*
		 * TestImpl ti = new TestImpl();
		 * ti.addNumbers(10,20);		 * 
		 */
			
		/*
		Test ti = new Test() {			
			
			public void addNumbers(int a, int b) {				
				System.out.println(a+b);
			}
		};
		
		ti.addNumbers(10,20);
		*/
		
		Test ti =  (a, b) -> System.out.println(a+b);					
		ti.addNumbers(20,30);

	}

}
