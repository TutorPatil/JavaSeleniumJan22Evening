package com.corejava.collections;

public interface Test {	
	
	void addNumbers(int a, int b);

}
