package com.corejava.oops.poly;

public class TestPoly {

	public static void main(String[] args) {
	
		Dog d = new Dog();
		Cat c = new Cat();
		
		
		Animal a = new Cat();
		
		a.eat();
		a.sleep();
		a.drink();
		
		//byte b = (byte)150;
		
		if ( a instanceof Cat)
		{
			((Cat)a).huntRat(); // a is down casted to the Cat Level
		}
		

		if ( a instanceof Dog)
		{
			((Dog)a).bark(); // a is down casted to the Cat Level
		}
		
	
		// a.huntRat()  // Not allowed 
		
		
		Animal[] animalArray = {a,d,c};
		
		Dog[] dArray = {d};
		
		Object[] objArray = { a,d,c,"Java"};
		
		
		
	}

}
