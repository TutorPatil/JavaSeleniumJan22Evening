package com.corejava.oops.poly;

public class Dog extends Animal {

	public void eat()
	{
		System.out.println(" The Dog is eating");
	}
	
	public void bark()
	{
		System.out.println(" The  Dog is braking....bow bow..");
	}

	
	public void sleep() {
		System.out.println(" The Dog is sleeping deeply...");
		
	}
	
	
}
