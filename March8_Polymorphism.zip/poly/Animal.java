package com.corejava.oops.poly;

public abstract class Animal {
	
	int age;
	String name;
	
	
	public void eat()
	{
		System.out.println(" The animal is eating");
	}
	
	public void drink()
	{
		System.out.println(" The animal is drinking..");
	}
	
	public abstract void sleep();

}
