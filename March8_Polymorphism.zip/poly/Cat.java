package com.corejava.oops.poly;

public class Cat extends Animal {
	
	public void eat()
	{
		System.out.println(" The Cat is eating");
	}

	
	public void huntRat()
	{
		System.out.println(" The Cat is hunting Rat...");
	}
	
	public void sleep() {
		System.out.println(" The Cat  is sleeping but still it is active..");
		
	}
	
	
}
