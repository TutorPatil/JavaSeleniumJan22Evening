package com.corejava.oops.inheritance;

public class Dog extends Animal {
	
	public int age;
	public String name;
	
	public Dog()
	{	
		super();
		System.out.println(" Inside the Dog's Default COnstructor");
	}
	
	public Dog(int age, String name, int pAge, String pName)
	{
		super(pAge,pName);
		this.age = age;
		this.name = name;
		
	}
	
	public void bark()
	{
		System.out.println(" The Dog of the colour"+ colour + " is  barking...");
		
	}
	
	// Final method from the parent class cant be overridden
	/*
	 * public final void sleep() { System.out.println(" The Dog by name "+name +
	 * " of the age "+ age + " of the colour "+ colour +"is sleeping..."); }
	 */
	
	
	 
	
	public void eat()
	{
		System.out.println(" The Dog by name "+name + 
				" of the age "+ age + " of the colour "+ colour +"is eating...by moving its tail..");
			System.out.println(age);
	}
	
	public void eat(String food)
	{
		
		
		System.out.println(" The Dog by name "+name + 
				" of the age "+ age + " of the colour "+ colour +"is eating...by moving its tail..food is"+food);
	}

	
	public void drink() {
		
		super.eat();
		System.out.println(super.age);
		System.out.println(" The dog is drinking,,,,");
		
	}

}
