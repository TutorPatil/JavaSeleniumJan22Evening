package com.corejava.oops.inheritance;

public abstract class Animal {

	public int age ;
	public String name ;
	
	public Animal( int age, String name)
	{
		this.age = age;
		this.name = name;
		
	}
	public Animal()
	{
		super();
		System.out.println(" Inside the Animal Default COnstructor");
	}
	
	
	public String colour;
	
	public  abstract void drink();
	
	
	
	private void identifyYourChild()
	{
		System.out.println(" The animal can indentify its child");
	}
	
	public void eat()
	{
		System.out.println(" The animal by name "+name + 
				" of the age "+ age + " of the colour "+ colour +"is eating...");
	}
	
	public final  void sleep()
	{
		System.out.println(" The animal by name "+name + 
				" of the age "+ age + " of the colour "+ colour +"is sleeping...");
	}
}
