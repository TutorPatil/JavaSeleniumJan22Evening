package com.corejava.oops.inheritance;

public class Cat extends Animal{

	
	public void drink() {
		System.out.println("The cat is drinking...");
		
	}


}
