package com.corejava.oops.inheritance;

import java.util.Arrays;

public class TestDogInheritance {
	
	/*
	 * - Public members will getinherited
- Private members  can't be inherited
- In the child class methods can be over ridden by chnging the implementation
- final methods cant be over ridden
- Once we override any method in the child class, it can  be over loaded again in the child class.


	 */

	public static void main(String[] args) {	
		
		/*
		Dog d = new Dog();
		
		Cat c = new Cat();
		
		Animal.makeAnimalEat(d);
		Animal.makeAnimalEat(c);
		
		*/
		
		Dog d = new Dog();
		d.age = 5;
		
		Dog d1 = new Dog();
		d1.age = 5;
		
		
		System.out.println(d.equals(d1));
		
		
		
		
		
		
		
	}

}
