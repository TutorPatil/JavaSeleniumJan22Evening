package com.corejava.oops.inheritance;

public abstract class Animal {

	public int age ;
	public String name ;
	
	public Animal( int age, String name)
	{
		this.age = age;
		this.name = name;
		
	}
	public Animal()
	{
		super();
		//System.out.println(" Inside the Animal Default COnstructor");
	}
	
	public static void makeAnimalEat( Object d)
	{
		
		if ( d instanceof Dog)
		{
			((Dog)d).eat();
		}
	}
	
	public static Object[] creaeDogObject()
	{
		Dog d = new Dog();
		
		Cat c = new Cat();
		int[] x = {1,2,3,4};
		
		Object[] obj = {d,c,"selenium",x};
		return obj;
		
	}
	
	public int addNumbers(int x, int y)
	{
		int sum; 
		sum = ( x+y);
		return sum;
	}
			
	
	
	public String colour;
	
	public  abstract void drink();
	
	
	
	private void identifyYourChild()
	{
		System.out.println(" The animal can indentify its child");
	}
	
	public void eat()
	{
		System.out.println(" The animal by name "+name + 
				" of the age "+ age + " of the colour "+ colour +"is eating...");
	}
	
	public final  void sleep()
	{
		System.out.println(" The animal by name "+name + 
				" of the age "+ age + " of the colour "+ colour +"is sleeping...");
	}
}
