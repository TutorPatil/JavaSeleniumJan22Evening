package com.corejava.oops.inheritance;

public abstract class Animal {

	public int age ;
	public String name ;
	
	public Animal( int age, String name)
	{
		this.age = age;
		this.name = name;
		
	}
	public Animal()
	{
		super();
		System.out.println(" Inside the Animal Default COnstructor");
	}
	
	public static void makeAnimalEat( int x, Dog d)
	{
		d.eat();
	}
	
	public static Dog creaeDogObject()
	{
		Dog d = new Dog();
		return d;
		
	}
	
	public int addNumbers(int x, int y)
	{
		int sum; 
		sum = ( x+y);
		return sum;
	}
			
	
	
	public String colour;
	
	public  abstract void drink();
	
	
	
	private void identifyYourChild()
	{
		System.out.println(" The animal can indentify its child");
	}
	
	public void eat()
	{
		System.out.println(" The animal by name "+name + 
				" of the age "+ age + " of the colour "+ colour +"is eating...");
	}
	
	public final  void sleep()
	{
		System.out.println(" The animal by name "+name + 
				" of the age "+ age + " of the colour "+ colour +"is sleeping...");
	}
}
