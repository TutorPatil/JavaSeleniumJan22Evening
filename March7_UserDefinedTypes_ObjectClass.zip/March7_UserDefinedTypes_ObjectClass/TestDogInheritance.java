package com.corejava.oops.inheritance;

import java.util.Arrays;

public class TestDogInheritance {
	
	/*
	 * - Public members will getinherited
- Private members  can't be inherited
- In the child class methods can be over ridden by chnging the implementation
- final methods cant be over ridden
- Once we override any method in the child class, it can  be over loaded again in the child class.


	 */

	public static void main(String[] args) {	
		
		Dog d = new Dog(5, "Cheetu",50,"prani");
		
		Dog d1 = new Dog(15, "Teeku",60,"prani");
		
		
		System.out.println(d.getClass());
		
		
		System.out.println(d.hashCode());
		
		System.out.println(d1.hashCode());
		
		//d=d1;
		
		//System.out.println(d.hashCode());		
		//System.out.println(d1.hashCode());
		
		
		System.out.println(d);
		
		//System.out.println(d1);
		
		System.out.println(d.toString());
		
		/*
	
		//Dog d = new Dog();
		Dog d = new Dog(5, "Cheetu",50,"prani");
		
		Dog d1 = Animal.creaeDogObject();
		
		Animal.makeAnimalEat(10, d1);	
		
		Dog[] dArray = {d,d1};
		
		
		
		
	
		
		//d.age = 5;
		//d.name = "Cheetu";
		d.colour ="black";
		
		d.eat();
		d.sleep();
		d.bark();
		
	
		/*
		System.out.println("+++++++++++++++++++++++++");
		
		Cat c = new Cat();
		c.age = 2;
		c.name = "Billi";
		c.colour = "white";
		
		
		c.eat();
		c.sleep();
		c.hutRat();
		c.walk();
		*/

	}

}
