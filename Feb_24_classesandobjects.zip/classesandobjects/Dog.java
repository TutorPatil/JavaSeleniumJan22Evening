package com.java.classesandobjects;

public class Dog {
	
	String colour;
	int age ;
	String breed ;
	boolean isVaccinated ;
	static int noOfLegs = 4;
	
	
	
	public void bark()
	{
		System.out.println("The Dog of the breed "+breed + " of the colour "+ colour +
				"Of the age "+age + " which is vaccinated "+ isVaccinated +" is barking bow bow...");
	}
	

}
