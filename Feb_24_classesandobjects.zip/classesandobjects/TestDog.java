package com.java.classesandobjects;

public class TestDog {

	public static void main(String[] args) {
	
		Dog d = new Dog();
		
		d.age = 5;
		d.breed = "German Shephered";
		d.colour="Black";
		d.isVaccinated = true;
		
		d.bark();
		
		System.out.println("====================");
		
		Dog d1 = new Dog();
		
		d1.age = 1;
		d1.breed ="pumorian";
		d1.colour="white";
		d1.isVaccinated = false;
		
		d1.bark();
		
		
		d=d1;
		
		
		System.out.println("++++++++++++++++++++");
		
		d.bark();
		d1.bark();
		
		d = null;
		
		d.bark();

	}

}
