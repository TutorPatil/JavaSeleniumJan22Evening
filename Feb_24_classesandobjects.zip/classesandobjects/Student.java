package com.java.classesandobjects;

public class Student {
	
	String name;
	int rollNum;
	int standard;
	int feesPaid;
	int feesDue;
	String gender;
	Address a;	
	static Address a1;	
	static Address out ;
	
	static String schoolName = "Govt Primary School";
	
	
	public void doHomeWork()
	{
		System.out.println("The student by name "+name + " has done the homework");		
	}
	
	public void payYourFess()
	{
		System.out.println("The student by name "+name + " has fees due of amount "+feesDue);		
	}
	
	public String getStudentAddressDetails()
	{
		return "Name " +name + " adress Details " + a.getAddressDetails();
		
	}
	
	
	public static void attendExams()
	{
		System.out.println("The student of the school "+schoolName + " has not attended the exams ");
	}


}
