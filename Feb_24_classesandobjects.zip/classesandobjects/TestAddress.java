package com.java.classesandobjects;

public class TestAddress {

	public static void main(String[] args) {

		Student s = new Student();
		
		s.name = "Ramu";
		s.rollNum =15;
		
		Address a = new Address();
		a.area="BTM";
		a.city="Bangalore";
		a.flatNo=150;
		
		s.a = a;
		
		Student.a1 =a;
		
		System.out.println(s.schoolName);
		
		System.out.println(Address.getStateFromAddress());
		
			
		System.out.println(s.a.getAddressDetails());
		
		Student.out.getAddressDetails();
		
		
		Student.a1.getAddressDetails();
		
		System.out.println("welcome");
		
		
		
		System.out.println(Student.a1.getStateFromAddress());
		
		
		
				
		
		

	}

}
