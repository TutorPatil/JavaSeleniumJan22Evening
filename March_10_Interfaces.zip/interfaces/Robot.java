package com.corejava.interfaces;

public interface Robot {
	
	void doWhatOwnerSays();

}
