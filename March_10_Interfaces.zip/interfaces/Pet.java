package com.corejava.interfaces;

public class Pet {
	
	public void playWithTheOwners()
	{
		System.out.println(" The Pet is happily playing with its Parent..");
	}

}
