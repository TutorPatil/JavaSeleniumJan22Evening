package com.corejava.interfaces;

public interface SuperAnimal {
	
	void dance();

}
