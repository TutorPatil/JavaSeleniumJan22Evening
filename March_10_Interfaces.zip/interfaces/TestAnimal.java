package com.corejava.interfaces;

public class TestAnimal {

	public static void main(String[] args) {
	
		//Dog d = new Dog();
		
		Animal a = new Cat();
		
		a.eat();
		a.sleep();
		a.drink();
		a.dance();
		
		Animal.feedYourBabyAnimals();
		
		a.walk();
	}

}
