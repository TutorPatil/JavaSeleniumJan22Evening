package com.corejava.interfaces;

public interface Animal extends SuperAnimal{
	
	public static final int noOfLegs = 4;  // Public static and final...
	String name = "Prani";
	
		
	public abstract void eat();
	void sleep(); // By default all the methods of java interface are public and abstract...
	void drink();
	
	public static void feedYourBabyAnimals()
	{
		System.out.println(" All the animals need to take care of their babies...");
	}
	
	default void  walk()
	{
		System.out.println(" The animal can walk...");
	}
	
	
	
	
	
	
	
	
	

}
