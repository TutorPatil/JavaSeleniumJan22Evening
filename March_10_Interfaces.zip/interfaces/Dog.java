package com.corejava.interfaces;

public class Dog extends Pet implements Animal ,Robot{

	
	public void eat() {
		System.out.println(" The Dog is eating....");
		
	}

	
	public void sleep() {
		System.out.println(" The Dog is sleeping........");
		
	}

	
	public void drink() {
		System.out.println(" The Dog is drinking........");
		
	}


	public void dance() {
		System.out.println(" The dog is dancing....");
		
	}


	
	public void doWhatOwnerSays() {
		System.out.println(" The dog is a Pet and a Robot and can obay his owner..");
		
	}
	
	

}
