package com.corejava.oops.inheritance;

public class Cat extends Animal {
	
	public void hutRat()
	{		
		System.out.println(" The cat of the age "+ age + " of the colour "+colour +" is huntting Rat");
	}
	
	public void eat()
	{
		System.out.println(" The Cat by name "+name + 
				" of the age "+ age + " of the colour "+ colour +"is eating...by making sound maow sound.....");
	}

}
