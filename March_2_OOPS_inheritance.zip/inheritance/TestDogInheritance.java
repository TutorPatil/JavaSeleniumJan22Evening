package com.corejava.oops.inheritance;

public class TestDogInheritance {
	
	/*
	 * - Public members will getinherited
- Private members  can't be inherited
- In the child class methods can be over ridden by chnging the implementation
- final methods cant be over ridden
- Once we override any method in the child class, it can  be over loaded again in the child class.


	 */

	public static void main(String[] args) {
		
		//final int x = 10;
		//x = 20;
		
		
	
		Dog d = new Dog();
		d.age = 5;
		d.name = "Cheetu";
		d.colour ="black";
		
		d.eat();
		d.sleep();
		d.bark();
		
		System.out.println("+++++++++++++++++++++++++");
		
		Cat c = new Cat();
		c.age = 2;
		c.name = "Billi";
		c.colour = "white";
		
		
		c.eat();
		c.sleep();
		c.hutRat();
		
		

	}

}
