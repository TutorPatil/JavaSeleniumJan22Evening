package com.corejava.finalsession;

public class Student {
	
	// Step 2 create the object of the same class in the global variable area
	public static Student s = new Student();
	
	
	//Step 1 write private constructor
	private Student()
	{
		
	}
	
	// write a method to return the same object every time
	public static Student getStudentObject()
	{
		return s;
	}
	
	
	public void test()
	{
		System.out.println("Test method...");
	}
	
}
