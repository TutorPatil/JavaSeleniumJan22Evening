package com.corejava.finalsession;

//public class Mobile implements Comparable<Mobile>{
public class Mobile {
	
	int ram;
	String colour;
	double price;
	
	public Mobile(int ram, String colour, double price) {	
		
		this.ram = ram;
		this.colour = colour;
		this.price = price;
	}
	
	public String toString()
	{
		return " --Ram-- "+ram+" --Colour-- "+colour+" --Price-- "+price;
	}
	/*
	 * 
	 * public int compareTo(Mobile o) { if( this.ram > o.ram) { return 1; } else {
	 * return -1; } }
	 */	
	
	
	
	

}
