package com.corejava.finalsession;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class TestMobile {
	
	public static void main(String[] args) {
		
		Mobile m1 = new Mobile(2, "Black",5000.00);
		Mobile m2 = new Mobile(1, "White",4000.00);
		Mobile m3 = new Mobile(3, "Gray",5500.00);
		
		
		List<Mobile> mList = new ArrayList<Mobile>();
		
		mList.add(m1);
		mList.add(m2);
		mList.add(m3);
		
		System.out.println(mList);
		System.out.println(" Before sort ");
		
		Comparator<Mobile> comp = new Comparator<Mobile>() {
			
			public int compare(Mobile o1, Mobile o2) {			
					if(o1.price > o2.price)
					{
						return 1;
					}
					else
					{
						return -1;
					}
			}
			
		};
		
		Collections.sort(mList,comp);
		
		System.out.println(mList);
		
		
	}

	
	
}
