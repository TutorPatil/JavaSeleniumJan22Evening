package com.corejava.finalsession;

public class TestSingleton {

	public static void main(String[] args) {

		Student s = Student.getStudentObject();
		s.test();
		System.out.println(s);
		
		Student s1 = Student.getStudentObject();
		s1.test();
		System.out.println(s);


	}

}
