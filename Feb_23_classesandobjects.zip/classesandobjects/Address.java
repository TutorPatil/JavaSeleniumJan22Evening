package com.java.classesandobjects;

public class Address {
	
	int flatNo;
	String streetName;
	String area;
	String city;
	int pincode;
	
	public String getAddressDetails()
	{
		
		return "The address details are "+ "flatNo " + flatNo+ "streetName "+streetName + "Area " + area + "city " + city + "pincode "+pincode; 
	}

}
