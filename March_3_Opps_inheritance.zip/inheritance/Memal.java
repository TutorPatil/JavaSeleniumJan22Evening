package com.corejava.oops.inheritance;

public abstract class Memal extends Animal{
	
	public void walk()
	{
		System.out.println(" The memal is walking");
	}
	

	
	public void eat()
	{
		System.out.println(" The Memal by name "+name + 
				" of the age "+ age + " of the colour "+ colour +"is eating...by moving its tail..");
	}

}
