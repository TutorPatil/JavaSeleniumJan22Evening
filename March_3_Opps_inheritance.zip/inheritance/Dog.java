package com.corejava.oops.inheritance;

public class Dog extends Memal {
	
	public void bark()
	{
		System.out.println(" The Dog of the colour"+ colour + " is  barking...");
		
	}
	
	// Final method from the parent class cant be overridden
	/*
	 * public final void sleep() { System.out.println(" The Dog by name "+name +
	 * " of the age "+ age + " of the colour "+ colour +"is sleeping..."); }
	 */
	
	
	 
	
	public void eat()
	{
		System.out.println(" The Dog by name "+name + 
				" of the age "+ age + " of the colour "+ colour +"is eating...by moving its tail..");
	}
	
	public void eat(String food)
	{
		System.out.println(" The Dog by name "+name + 
				" of the age "+ age + " of the colour "+ colour +"is eating...by moving its tail..food is"+food);
	}

	
	public void drink() {
		System.out.println(" The dog is drinking,,,,");
		
	}

}
