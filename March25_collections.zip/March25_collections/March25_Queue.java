package com.corejava.collections;

import java.util.PriorityQueue;
import java.util.Queue;

public class March25_Queue {

	public static void main(String[] args) {
		
		Queue<String> pq = new PriorityQueue<String>();
		
		pq.add("Selenium");
		pq.add("Java");
		pq.add("Automation");
		pq.offer("Testing");
		
		System.out.println(pq.size());
		System.out.println(pq);
		
		System.out.println(pq.poll());
		System.out.println(pq.size());
		
		
		System.out.println(pq);
		System.out.println(pq.peek());
		
		System.out.println(pq.size());
		

	}

}
