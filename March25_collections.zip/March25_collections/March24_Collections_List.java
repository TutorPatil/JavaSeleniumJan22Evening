package com.corejava.collections;

import java.util.ArrayList;
import java.util.List;

import com.java.classesandobjects.Student;

public class March24_Collections_List {

	public static void main(String[] args) {
		
		
		List<String> al = new ArrayList<String>(); // default size is  16	
		
		List<String> al1 = new ArrayList<String>(25); // initial Capacity
		
		
	}
	
	
	public static void arrayListEx4()
	{
List<String> al = new ArrayList<String>();
		
		al.add("java");
		al.add("selenium");
		al.add("Automation");
		al.add("java");
		
		for( int i=0; i<al.size();i++)
		{
			System.out.println(al.get(i));
		}
		
		System.out.println("=====================");
		
		for(String m : al)
		{
			System.out.println(m);
		}
	}
	
	public static void arraListEx3()
	{
		

		List<String> al = new ArrayList<String>();
		
		al.add("java");
		al.add("selenium");
		al.add("Automation");
		al.add("java");
		
		System.out.println(al);
		
		al.add(2, "Manual Testing");
		
		System.out.println(al);
		
		System.out.println(al.get(1));
		
		System.out.println(al.indexOf("java"));
		
		System.out.println(al.lastIndexOf("java"));
		
		al.set(1, "QTP");
		
		System.out.println(al);
		
		al.remove(0);
		
		System.out.println(al);
		
		List<String> al2 = new ArrayList<String>();
		
		al2.add("Data Base");
		al2.add("Unix");
		
		al.addAll(1, al2);
		
		System.out.println(al);

	}
	
	
	public static void ArralistEx2()
	{
List<String> al = new ArrayList<String>();
		
		al.add("java");
		al.add("selenium");
		al.add("Automation");
		al.add("java");
		
		
		System.out.println(al);
		
		al.remove("java");
		
		System.out.println(al);
		
		System.out.println(al.size());
	}
	
	public static void ArrayListEx1()
	{

		Student s = new Student();
		Student s1 = new Student();
		
		List al = new ArrayList();
		
		al.add("Java");
		al.add(25);  // 25 is auto boxed and converted to Integer Object
		al.add("Java");
		al.add(s);
		al.add(s1);
		al.add(null);
		al.add(100);
		
		
		System.out.println(al);
		
		System.out.println(al.size());
		
		System.out.println(al.contains("java"));
		
		al.remove(s);
		System.out.println(al.size());
		
		System.out.println(al);
		
		
		//al.clear();		
		//System.out.println(al.size());
		
		System.out.println(al.isEmpty());
		
		List al1 = new ArrayList();
			al1.add("selenim");
			al1.add("Automation");
			al1.add(200);
			
		al.addAll(al1);
		
		System.out.println(al);
		
		al.removeAll(al1);
		
		System.out.println(al);
		
	}

}
