package com.corejava.collections;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

public class March25_SetAndQueue {

	public static void main(String[] args) {
		

	}
	
	public static void iterateaSet()
	{

		Set<String> tSet = new TreeSet<String>();
		
		tSet.add("Java");
		tSet.add("Selenium");
		tSet.add("Automation");
		tSet.add("Testing");
		
		System.out.println(tSet);
		
//		for( String m :tSet)
//		{
//			System.out.println(m);
//		}
		
		Iterator<String> itr = tSet.iterator();
		
		while(itr.hasNext())
		{
			System.out.println(itr.next());
			
		}
		

	}
	
	
	public static void treeSetEx2()
	{

		Set<Integer> tSet = new TreeSet<Integer>();
		tSet.add(500);
		tSet.add(50);
		tSet.add(250);
		tSet.add(5);
		
		System.out.println(tSet);
	}
	public static void treeSetEx1()
	{

		Set<String> tSet = new TreeSet<String>();
		
		tSet.add("Java");
		tSet.add("Selenium");
		tSet.add("Automation");
		tSet.add("Testing");
		
		
		System.out.println(tSet);
		
	}
	
	public static void hashSetUniqueCharactersFromString()
	{
		Set<Character> cSet = new HashSet<Character>();	
		
		String s = "selenium";
		
		char[] c = s.toCharArray();
		
//		for( int i=0; i<c.length;i++)
//		{
//			char c1 = c[i];
//			cSet.add(c1);
//			
//		}
		
		for( int i=0; i<s.length(); i++)
		{
			char c1 = s.charAt(i);
			cSet.add(c1);
		}
		
		System.out.println(cSet);
	}
	
	public static void hashSetEx2()
	{
		Set hs = new HashSet();
		
		hs.add("Selenium");
		hs.add("Java");
		hs.add(500);
		System.out.println(hs);
				
	}
	
	public static void hashSetEx1()
	{
		Set<String> hs = new HashSet<String>();
		
		hs.add("Java");
		hs.add("Selenium");
		hs.add("Automation");
		hs.add("Testing");
		System.out.println(hs.add("Java"));
		
		
		System.out.println(hs);
	}

}
