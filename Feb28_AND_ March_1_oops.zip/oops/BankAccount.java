package com.corejava.oops;

public class BankAccount {
	
	private int accountNumber ;
	private int balance = 5000;   // no setter method for balance
	
	public int getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	public int getBalance() {
		return balance;
	}
	
	
	public void withdrawAmount(int amount)
	{
		boolean status = checkbalanceBeforeWithDraw(amount);
		if ( status )
		{
			System.out.println(" your  amount of "+ amount +" is been dispensed and pls collect your  cash");
		}
		else
		{
			System.out.println(" your  amount of "+ amount +" is less than the current balance Please enter amount less than the balance ");
		}
	}
	
	private boolean checkbalanceBeforeWithDraw(int amount)
	{
		if( amount <= balance)
		{
			balance = balance - amount;
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public void depositAmount( int amount )
	{
		updateBalanceonDeposit(amount);
		
		System.out.println(" Your amount of "+ amount + " is been successfully deposited  Your balance is  "+balance);
	}
	
	private void updateBalanceonDeposit(int amount)
	{
		balance = balance + amount;
	}
	
	
	
	
	
	
	
	
	
	
	

}
