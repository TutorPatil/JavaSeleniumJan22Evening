package com.corejava.oops;

public class TestDog {

	public static void main(String[] args) {
	
		Dog d = new Dog();
		
		d.setAge(8);
		d.setBreed("Boxer");
		d.setColour("Black");
		
		
		//d.age = -5;
		//d.colour =" Black";
		//d.breed = "Boxer";
		
		d.bark();
		
		int age = d.getAge();
		
		System.out.println(age);
		

	}

}
