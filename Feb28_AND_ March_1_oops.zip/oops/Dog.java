package com.corejava.oops;

public class Dog {
	
	
	private int age;
	private String colour;
	private String breed;
	
	
	public String getColour() {
		return colour;
	}

	public void setColour(String colour) {
		this.colour = colour;
	}

	public String getBreed() {
		return breed;
	}

	public void setBreed(String breed) {
		this.breed = breed;
	}

	public void setAge(int age)
	{
		if( (age > 0) && (age < 20))
		{
			this.age = age;
			
		}
		else
		{
			System.out.println(" Please enter correct value for the age variable....");
		}
		
	}
	
	public int getAge()
	{
		return age;
	}
	
	public void bark()
	{
		if( (age > 0)  && (age < 10)) {
			System.out.println(" The Dog of the age "+age +" colour "+colour +" breed "+breed + " is barking bow bow...");
		}
		else if( (age > 10)  && (age < 20)) {
			System.out.println("The Dog of the age "+age +" colour "+colour +" breed "+breed + " is barking Ruff ruff bow bow...");
		}
		
	}

}
