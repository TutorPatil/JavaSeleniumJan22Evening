package com.corejava.oops;

public class TestBankAccount {

	public static void main(String[] args) {
	
		BankAccount b1 = new BankAccount();
		b1.setAccountNumber(123456);
		
		b1.depositAmount(4000);
		
		System.out.println(b1.getBalance());
		
		b1.withdrawAmount(3000);
		
		System.out.println(b1.getBalance());

	}

}
