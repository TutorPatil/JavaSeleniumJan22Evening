package com.corejava.collections;

public class TestNestedInterfaces {

	public static void main(String[] args) {
		
		WebDriver driver = new ChromeDriver();
		driver.getCurrentUrl();
		

	}

}
