package com.corejava.collections;

public class RecurssionExample {

	public static void main(String[] args) {
		showNumbers(5);
	}
	public static void showNumbers(int num)
	{
		
		if( num > 0)
		{
			showNumbers(num - 1);
		}
		
		System.out.println(num);
		
	}
	
	
}
