package com.corejava.collections;

public class Outer {
	
	int oAge = 15;
	String oName = "Ramu";
	InnerClass in ;
	
	public void getAgeAndName()
	{
		System.out.println(oName +"---"+ oAge);
		in = new InnerClass();
		System.out.println(in.iAge);	
		InnerPrivate inPvt = new InnerPrivate();
	}	
	
	public void test()
	{
		System.out.println(oName +"---"+ oAge);
	}
	
	
	class InnerClass{
		
		int iAge = 12;
		String iName = "RamaKrishna";		
		
		public void testInner()
		{
			System.out.println(oName);
			System.out.println(iName);
			InnerPrivate inPvt1 = new InnerPrivate();			
		}
	}
	
	private class InnerPrivate{
		
		int pvAge = 5;
		
		public void testInnerPrivateMethod()
		{
			System.out.println(pvAge);
			System.out.println(oName);
		}
		
		
	}
	
	static class InnerStatic{
		
		static int innerStaticAge = 10;
		String innerStaticName="Shamu";
		
		
		
		
	}

}
