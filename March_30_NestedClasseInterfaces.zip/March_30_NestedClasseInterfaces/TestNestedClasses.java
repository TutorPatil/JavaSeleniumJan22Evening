package com.corejava.collections;

public class TestNestedClasses {

	public static void main(String[] args) {
		
		Outer out = new Outer();
		out.test();
		
		Outer.InnerClass in = out.new InnerClass();
		in.testInner();
		
		
		//Outer.InnerPrivate in1 = out.new InnerPrivate();
		
		Outer.InnerStatic inStat = new Outer.InnerStatic();
		System.out.println(inStat.innerStaticName);
		
		System.out.println(Outer.InnerStatic.innerStaticAge);
		
		
		
		
	}

}
