package com.corejava.collections;

public interface WebDriver {

	 int age = 10;	
	 void getCurrentUrl();
	 
	 interface Window{
		 
		 int innerAge = 5;
		 void testInner();
		 
	 }	 
	 
	 static interface TimeOut{ 
		 
		 
	 }
	 
	 
}
